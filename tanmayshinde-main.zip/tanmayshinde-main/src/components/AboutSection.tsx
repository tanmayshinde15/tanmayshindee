import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, Zap, TrendingUp, Award } from 'lucide-react';

const AboutSection = () => {
  const highlights = [
    {
      icon: <GraduationCap className="w-6 h-6" />,
      title: "Recent Graduate",
      description: "B.E. in Instrumentation and Control Engineering",
      color: "engineering"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Automation Expert",
      description: "PLC, SCADA, DCS, and industrial automation systems",
      color: "engineering"
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Trading Success",
      description: "Passed 6+ funded trading accounts with consistent performance",
      color: "trading"
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Dual Expertise",
      description: "Unique blend of engineering precision and financial strategy",
      color: "trading"
    }
  ];

  const skills = [
    "Problem Solving", "Team Collaboration", "Analytical Thinking", 
    "Adaptability", "Communication", "Risk Discipline", "Technical Leadership"
  ];

  return (
    <section id="about" className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="section-header">About Me</h2>
          <p className="section-subheader">
            A passionate engineer and trader combining technical expertise with financial acumen 
            to create innovative solutions and consistent market performance.
          </p>
        </div>

        {/* Profile Summary */}
        <div className="max-w-4xl mx-auto mb-16">
          <Card className="border-engineering/20 hover:border-engineering/40 transition-smooth">
            <CardContent className="p-8">
              <p className="text-lg text-muted-foreground leading-relaxed">
                Recent B.E. graduate in Instrumentation and Control Engineering with a unique dual expertise 
                spanning both engineering and financial markets. Skilled in PLC, SCADA, DCS, and automation 
                systems with hands-on experience in engineering projects. Successfully demonstrated exceptional 
                trading performance by passing <span className="text-trading font-semibold">6+ funded trading accounts</span> with 
                consistent profitability in Forex, Options, and Cryptocurrency markets. Passionate about 
                blending technology, automation, and financial analysis to drive innovation and success.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Key Highlights */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {highlights.map((highlight, index) => (
            <Card key={index} className={`card-${highlight.color} group`}>
              <CardContent className="p-6 text-center">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-4 ${
                  highlight.color === 'engineering' ? 'bg-engineering/10 text-engineering' : 'bg-trading/10 text-trading'
                } group-hover:scale-110 transition-bounce`}>
                  {highlight.icon}
                </div>
                <h3 className="font-semibold mb-2">{highlight.title}</h3>
                <p className="text-sm text-muted-foreground">{highlight.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Soft Skills */}
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-6">Core Competencies</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {skills.map((skill, index) => (
              <Badge 
                key={index} 
                variant="secondary" 
                className="px-4 py-2 text-sm hover:scale-105 transition-bounce cursor-default"
              >
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;