import { Button } from '@/components/ui/button';
import { Download, Mail, Phone, Github, Linkedin } from 'lucide-react';
import profileImage from '@/assets/tanmay-profile.jpg';
const HeroSection = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };
  return <section id="hero" className="min-h-screen flex items-center justify-center bg-gradient-hero relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-engineering rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-trading rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between max-w-6xl mx-auto">
          
          {/* Profile Image */}
          <div className="lg:w-1/3 mb-12 lg:mb-0">
            
          </div>

          {/* Content */}
          <div className="lg:w-2/3 lg:pl-16 text-center lg:text-left">
            <div className="space-y-6">
              <div>
                <p className="text-engineering text-lg font-semibold mb-2">Hello, I'm</p>
                <h1 className="text-5xl lg:text-7xl font-bold mb-4">
                  <span className="bg-gradient-to-r from-engineering to-trading bg-clip-text text-transparent">
                    Tanmay Shinde
                  </span>
                </h1>
                <div className="text-xl lg:text-2xl text-muted-foreground space-y-2">
                  <p>Instrumentation and Control Engineer</p>
                  <p className="text-trading">Forex & Options Trader</p>
                  <p className="text-engineering">Cryptocurrency Analyst</p>
                </div>
              </div>

              {/* Contact Info */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+91 7719995355</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>tanmayshinde699@gmail.com</span>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                
                <Button variant="outline" className="btn-outline-trading" onClick={scrollToContact}>
                  Contact Me
                </Button>
              </div>

              {/* Social Links */}
              <div className="flex gap-4 justify-center lg:justify-start">
                <a href="https://linkedin.com/in/tanmay-shinde" target="_blank" rel="noopener noreferrer" className="p-3 rounded-full border border-border hover:border-engineering hover:text-engineering transition-smooth hover:scale-110">
                  
                </a>
                <a href="https://github.com/tanmay-shinde" target="_blank" rel="noopener noreferrer" className="p-3 rounded-full border border-border hover:border-trading hover:text-trading transition-smooth hover:scale-110">
                  
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default HeroSection;