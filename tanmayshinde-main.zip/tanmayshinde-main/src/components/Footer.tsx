import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Download, Mail, Phone, Github, Linkedin, MapPin } from 'lucide-react';
const Footer = () => {
  return <footer id="contact" className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Contact Section */}
          <div className="text-center mb-16">
            <h2 className="section-header">Get In Touch</h2>
            <p className="section-subheader">
              Ready to discuss engineering projects or trading strategies? Let's connect!
            </p>
          </div>

          {/* Contact Cards */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {/* Engineering Contact */}
            <Card className="card-engineering">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-engineering/10 text-engineering mb-6">
                  <Mail className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-engineering">Engineering Inquiries</h3>
                <p className="text-muted-foreground mb-6">
                  Automation projects, PLC programming, industrial control systems
                </p>
                <div className="space-y-3">
                  <a href="mailto:tanmayshinde699@gmail.com?subject=Engineering Project Inquiry" className="flex items-center justify-center gap-3 text-engineering hover:scale-105 transition-bounce">
                    <Mail className="w-5 h-5" />
                    <span>tanmayshinde699@gmail.com</span>
                  </a>
                  <a href="tel:+917719995355" className="flex items-center justify-center gap-3 text-engineering hover:scale-105 transition-bounce">
                    <Phone className="w-5 h-5" />
                    <span>+91 7719995355</span>
                  </a>
                </div>
              </CardContent>
            </Card>

            {/* Trading Contact */}
            <Card className="card-trading">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-trading/10 text-trading mb-6">
                  <Phone className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-trading">Trading Discussions</h3>
                <p className="text-muted-foreground mb-6">
                  Market analysis, trading strategies, prop firm challenges
                </p>
                <div className="space-y-3">
                  <a href="mailto:tanmayshinde699@gmail.com?subject=Trading Discussion" className="flex items-center justify-center gap-3 text-trading hover:scale-105 transition-bounce">
                    <Mail className="w-5 h-5" />
                    <span>tanmayshinde699@gmail.com</span>
                  </a>
                  <a href="tel:+917719995355" className="flex items-center justify-center gap-3 text-trading hover:scale-105 transition-bounce">
                    <Phone className="w-5 h-5" />
                    <span>+91 7719995355</span>
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Resume Download */}
          <div className="text-center mb-16">
            <Card className="border-primary/20 hover:border-primary/40 transition-smooth">
              <CardContent className="p-8">"Thank you for visiting my portfolio. I appreciate your time and interest" </CardContent>
            </Card>
          </div>

          {/* Social Links & Footer Info */}
          <div className="border-t border-border pt-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              {/* Social Links */}
              <div className="flex items-center gap-4">
                <span className="text-muted-foreground">Connect with me</span>
                
                
              </div>

              {/* Copyright */}
              <div className="text-center md:text-right">
                <p className="text-muted-foreground">
                  © 2025 Tanmay Shinde. All rights reserved.
                </p>
                <p className="text-sm text-muted-foreground/80">
                  Instrumentation Engineer | Professional Trader
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;