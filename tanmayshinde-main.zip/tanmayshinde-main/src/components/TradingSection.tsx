import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  Target, 
  BarChart3, 
  DollarSign, 
  Trophy, 
  Zap,
  PieChart,
  Activity,
  TrendingDown
} from 'lucide-react';

const TradingSection = () => {
  const achievements = [
    {
      icon: <Trophy className="w-8 h-8" />,
      title: "6+ Funded Accounts",
      description: "Successfully passed multiple prop firm challenges",
      highlight: "Consistent Performance"
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: "Multi-Market Expertise",
      description: "Forex, Options, and Cryptocurrency trading",
      highlight: "Diversified Skills"
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: "Risk Management",
      description: "Portfolio optimization and trade discipline",
      highlight: "Proven Strategy"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Technical Analysis",
      description: "Advanced charting and market analysis",
      highlight: "Data-Driven"
    }
  ];

  const tradingSkills = [
    { 
      category: "Market Analysis", 
      skills: ["Technical Analysis", "Fundamental Analysis", "Market Psychology", "Pattern Recognition"],
      icon: <BarChart3 className="w-6 h-6" />
    },
    { 
      category: "Trading Strategies", 
      skills: ["Forex Scalping", "Options Strategies", "Swing Trading", "Risk-Reward Optimization"],
      icon: <Target className="w-6 h-6" />
    },
    { 
      category: "Risk Management", 
      skills: ["Position Sizing", "Stop Loss Strategy", "Portfolio Diversification", "Drawdown Control"],
      icon: <TrendingDown className="w-6 h-6" />
    },
    { 
      category: "Technology", 
      skills: ["Algorithmic Trading Basics", "Trading Platforms", "Market Data Analysis", "Automation Tools"],
      icon: <Activity className="w-6 h-6" />
    }
  ];

  const markets = [
    {
      name: "Forex Trading",
      description: "Major and minor currency pairs with focus on technical analysis and risk management",
      icon: <DollarSign className="w-6 h-6" />,
      color: "trading"
    },
    {
      name: "Options Trading",
      description: "Strategic options trading with emphasis on volatility and time decay management",
      icon: <PieChart className="w-6 h-6" />,
      color: "trading-secondary"
    },
    {
      name: "Cryptocurrency",
      description: "Digital asset analysis and trading across major cryptocurrencies and DeFi protocols",
      icon: <Activity className="w-6 h-6" />,
      color: "trading-accent"
    }
  ];

  const keyStrengths = [
    "Trading Psychology & Discipline",
    "Multi-Timeframe Analysis",
    "Volatility Pattern Recognition",
    "Prop Firm Challenge Expertise",
    "Consistent Profitability",
    "Risk-to-Reward Optimization"
  ];

  return (
    <section id="trading" className="py-20 bg-gradient-to-br from-background to-trading/5">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="section-header text-trading">Trading Profile</h2>
            <p className="section-subheader">
              Proven track record in financial markets with consistent profitability and risk management expertise
            </p>
          </div>

          {/* Key Achievements */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-trading flex items-center gap-3">
              <Trophy className="w-8 h-8" />
              Trading Achievements
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {achievements.map((achievement, index) => (
                <Card key={index} className="card-trading group">
                  <CardContent className="p-6 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 bg-trading/10 text-trading group-hover:scale-110 transition-bounce">
                      {achievement.icon}
                    </div>
                    <h4 className="font-bold text-lg mb-2">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
                    <Badge variant="secondary" className="border-trading/20 text-trading">
                      {achievement.highlight}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Trading Performance Highlight */}
          <div className="mb-16">
            <Card className="card-trading border-trading/30">
              <CardContent className="p-8">
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-trading/10 text-trading mb-6">
                    <TrendingUp className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Exceptional Trading Performance</h3>
                  <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                    Demonstrated consistent profitability by successfully passing <span className="text-trading font-bold">6+ funded trading accounts</span> across 
                    multiple prop firms. This achievement showcases disciplined risk management, strategic thinking, and the ability to perform 
                    under pressure in live market conditions with real capital at stake.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Market Expertise */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-trading flex items-center gap-3">
              <BarChart3 className="w-8 h-8" />
              Market Expertise
            </h3>
            <div className="grid lg:grid-cols-3 gap-6">
              {markets.map((market, index) => (
                <Card key={index} className="card-trading group">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-lg bg-trading/10 text-trading group-hover:scale-110 transition-bounce">
                        {market.icon}
                      </div>
                      <CardTitle className="text-xl">{market.name}</CardTitle>
                    </div>
                    <p className="text-muted-foreground">{market.description}</p>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>

          {/* Trading Skills */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-trading flex items-center gap-3">
              <Target className="w-8 h-8" />
              Trading Skills
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              {tradingSkills.map((skillGroup, index) => (
                <Card key={index} className="card-trading">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-trading/10 text-trading">
                        {skillGroup.icon}
                      </div>
                      <CardTitle className="text-xl text-trading">{skillGroup.category}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {skillGroup.skills.map((skill, skillIndex) => (
                        <Badge 
                          key={skillIndex} 
                          variant="outline" 
                          className="border-trading/30 hover:border-trading transition-smooth"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Key Strengths */}
          <div>
            <h3 className="text-3xl font-bold mb-8 text-trading flex items-center gap-3">
              <Zap className="w-8 h-8" />
              Key Strengths
            </h3>
            <Card className="card-trading">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {keyStrengths.map((strength, index) => (
                    <div key={index} className="flex items-center gap-3 p-4 rounded-lg bg-trading/5 hover:bg-trading/10 transition-smooth">
                      <div className="w-3 h-3 rounded-full bg-trading"></div>
                      <span className="font-medium">{strength}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TradingSection;