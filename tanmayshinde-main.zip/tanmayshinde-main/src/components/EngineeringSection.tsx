import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  GraduationCap, 
  Code, 
  Cpu, 
  Settings, 
  Briefcase, 
  Award,
  Calendar,
  MapPin,
  ExternalLink
} from 'lucide-react';

const EngineeringSection = () => {
  const education = [
    {
      degree: "B.E. Instrumentation and Control Engineering",
      institution: "Government College of Engineering and Research, Avasari Khurd, Pune",
      year: "2024",
      type: "Bachelor's"
    },
    {
      degree: "Diploma in Instrumentation",
      institution: "Government Polytechnic, Ahilyanagar",
      year: "2021",
      type: "Diploma"
    },
    {
      degree: "SSC",
      institution: "AES Rupibai Bora New English School, Ahmednagar",
      year: "2017",
      type: "Secondary"
    }
  ];

  const technicalSkills = [
    { category: "PLC & Automation", skills: ["Allen Bradley", "Siemens PLC", "SCADA", "DCS", "HMI"] },
    { category: "Programming", skills: ["Ladder Logic", "Embedded C", "Python", "MATLAB"] },
    { category: "Development Tools", skills: ["LabVIEW", "Simulink", "AutoCAD", "Industrial Software"] },
    { category: "Hardware", skills: ["Arduino", "Microcontrollers", "Sensors", "Industrial Instruments"] }
  ];

  const projects = [
    {
      title: "Warehouse Management System",
      description: "Automated inventory tracking system using Arduino and PLC integration for efficient warehouse operations.",
      technologies: ["Arduino", "PLC", "Sensors", "Database Integration"],
      icon: <Settings className="w-6 h-6" />
    },
    {
      title: "Line Tracing Robot",
      description: "Autonomous navigation robot using Arduino Uno and IR sensors for precise line following and obstacle detection.",
      technologies: ["Arduino Uno", "IR Sensors", "Motor Control", "C Programming"],
      icon: <Cpu className="w-6 h-6" />
    },
    {
      title: "Automated Elevator System",
      description: "Microcontroller-based elevator control system with efficient floor management and safety protocols.",
      technologies: ["Microcontroller", "Control Systems", "Safety Systems", "User Interface"],
      icon: <Code className="w-6 h-6" />
    }
  ];

  const certifications = [
    "Allen Bradley PLC Training for Beginners",
    "Siemens PLC Training",
    "Industrial Automation with PLC & SCADA",
    "Python 3.4.3 Training (IIT Bombay)",
    "SEBI – Investor Certification Examination"
  ];

  return (
    <section id="engineering" className="py-20 bg-engineering/5">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="section-header text-engineering">Engineering Profile</h2>
            <p className="section-subheader">
              Comprehensive expertise in instrumentation, control systems, and automation technologies
            </p>
          </div>

          {/* Education */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-engineering flex items-center gap-3">
              <GraduationCap className="w-8 h-8" />
              Education
            </h3>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <Card key={index} className="card-engineering">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between">
                      <div className="flex-1">
                        <h4 className="text-xl font-semibold mb-2">{edu.degree}</h4>
                        <p className="text-muted-foreground flex items-center gap-2 mb-2">
                          <MapPin className="w-4 h-4" />
                          {edu.institution}
                        </p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="secondary" className="border-engineering/20">
                          {edu.type}
                        </Badge>
                        <div className="flex items-center gap-2 text-engineering">
                          <Calendar className="w-4 h-4" />
                          <span className="font-semibold">{edu.year}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Technical Skills */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-engineering flex items-center gap-3">
              <Code className="w-8 h-8" />
              Technical Skills
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              {technicalSkills.map((skillGroup, index) => (
                <Card key={index} className="card-engineering">
                  <CardHeader>
                    <CardTitle className="text-xl text-engineering">{skillGroup.category}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {skillGroup.skills.map((skill, skillIndex) => (
                        <Badge 
                          key={skillIndex} 
                          variant="outline" 
                          className="border-engineering/30 hover:border-engineering transition-smooth"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Projects */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-engineering flex items-center gap-3">
              <Settings className="w-8 h-8" />
              Key Projects
            </h3>
            <div className="grid lg:grid-cols-3 gap-6">
              {projects.map((project, index) => (
                <Card key={index} className="card-engineering group">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 rounded-lg bg-engineering/10 text-engineering group-hover:scale-110 transition-bounce">
                        {project.icon}
                      </div>
                      <CardTitle className="text-lg">{project.title}</CardTitle>
                    </div>
                    <p className="text-muted-foreground text-sm">{project.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, techIndex) => (
                        <Badge 
                          key={techIndex} 
                          variant="secondary" 
                          className="text-xs border-engineering/20"
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Work Experience */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold mb-8 text-engineering flex items-center gap-3">
              <Briefcase className="w-8 h-8" />
              Work Experience
            </h3>
            <Card className="card-engineering">
              <CardContent className="p-8">
                <div className="flex flex-col md:flex-row md:items-start justify-between mb-6">
                  <div>
                    <h4 className="text-xl font-semibold mb-2">Technical Intern</h4>
                    <p className="text-lg text-engineering font-medium mb-2">VINPAK Machine Pvt. Ltd</p>
                    <p className="text-muted-foreground">2023</p>
                  </div>
                  <Badge variant="outline" className="border-engineering/30 mt-2 md:mt-0">
                    Internship
                  </Badge>
                </div>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-engineering mt-2 flex-shrink-0"></div>
                    <span>Contributed to ZNC EDM Machines design and development process</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-engineering mt-2 flex-shrink-0"></div>
                    <span>Assisted in troubleshooting and reducing machine downtime</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-engineering mt-2 flex-shrink-0"></div>
                    <span>Collaborated in team updates and design improvements</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Certifications */}
          <div>
            <h3 className="text-3xl font-bold mb-8 text-engineering flex items-center gap-3">
              <Award className="w-8 h-8" />
              Certifications
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {certifications.map((cert, index) => (
                <Card key={index} className="card-engineering">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-engineering"></div>
                      <span className="font-medium">{cert}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EngineeringSection;