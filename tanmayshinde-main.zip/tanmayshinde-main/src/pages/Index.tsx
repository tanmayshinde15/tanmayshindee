import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import EngineeringSection from '@/components/EngineeringSection';
import TradingSection from '@/components/TradingSection';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <EngineeringSection />
      <TradingSection />
      <Footer />
    </div>
  );
};

export default Index;
